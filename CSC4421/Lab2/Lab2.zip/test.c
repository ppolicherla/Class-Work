#include <stdio.h>

int main(int argc, char * argv[])
{
	int a = 5;
	printf("Idiot: %s, %d\n", argv[1], 5);
	return 0;
}
