#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>

void listdir(const char *name, int level)
{
    DIR *dir;
    struct dirent *entry;
    struct stat st;
    int size;

    if (!(dir = opendir(name)))
        return;
    if (!(entry = readdir(dir)))
        return;
    do
    {
        if (entry->d_type == DT_DIR)
        {
            char path[1024];
            int len = snprintf(path, sizeof(path) - 1, "%s/%s", name, entry->d_name);
            path[len] = 0;
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
                continue;
            printf("%*s[%s]\n", level * 2, "", entry->d_name);
            listdir(path, level + 1);
            printf("\n%d\n", size);
        }
        else
        {
            printf("%*s- %s\n", level * 2, "", entry->d_name);
            stat(entry->d_name,&st);
            size=st.st_size;
            printf("\n%d\n", size);
        }
    } while (entry = readdir(dir));
    closedir(dir);
}

int main(void)
{
    listdir(".", 0);
    return 0;
}