//Programmed By: Pavan Policherla
//Lab 8
//10/7/2015
#include "SwimmingPool.h"
#include "Circle.h"
#include "Cylinder.h"
using namespace std;

int main()
{
	int length, depth, width, rate;
	cout << "Enter the length: ";
	cin >> length;
	cout << "Enter the width: ";
	cin >> width;
	cout << "Enter the depth: ";
	cin >> depth;
	cout << "Enter the rate to fill the pool: ";
	cin >> rate;
	swimmingPool swim(length, width, depth, rate);
	swim.fillTime();
	int height, radius;
	cout << "Please enter the height of the cylinder: ";
	cin >> height;
	cout << "Please enter the radius of the base: ";
	cin >> radius;
	cylinder cylinder(height, radius);
	cylinder.setRadius(radius);
	cout << "The area of the cylinder is: " << cylinder.surfaceArea() << endl;
	cout << "The volume of the cylinder is: " << cylinder.volume() << endl;
}