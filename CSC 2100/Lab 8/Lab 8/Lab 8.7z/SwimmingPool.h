#include<iostream>
using namespace std;

class swimmingPool
{
public:
	void fillTime();

	swimmingPool(int longs, int wide, int deep, int speed);
private:
	int length;
	int width;
	int depth;
	int rate;
	

};