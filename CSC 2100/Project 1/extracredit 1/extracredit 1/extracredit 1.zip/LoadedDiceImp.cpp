#include"LoadedDice.h"
using namespace std;

LoadedDice::LoadedDice()
{
	numSides = 6;
	srand(time(NULL));
}

LoadedDice::LoadedDice(int numsides)
{
	numSides = numsides;
	srand(time(NULL));
}

int LoadedDice::rollDice() const
{
	if ((rand() % 100 + 1) > 50)
	{
		return (rand() % numSides) + 1;
	}
	else
	{
		return numSides;
	}
}