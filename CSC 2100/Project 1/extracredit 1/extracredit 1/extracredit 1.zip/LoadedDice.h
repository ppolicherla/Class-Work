#include"Dice.h"
using namespace std;

class LoadedDice:public Dice
{
public:
	LoadedDice();
	LoadedDice(int numsides);
	virtual int rollDice()const;
private:
	int numSides;
};