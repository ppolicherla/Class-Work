//programmed by: Pavan Policherla
// lab10 excersise 2
// 10/14/2015

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
void input(string p[5], double *q[5], double total);
int main()
{
	double total = 19300;
	string *p = new string[5];
	double **q = new double *[5];
	input(p, q, total);
	cout << "Candidate" << "\t" << '\t' << "Number of Votes" << "\t" << '\t' << "% Total Votes" << endl;
	for (int i = 0; i < 5; i++)
	{
		cout << p[i]<<setw(8);
		for (int j = 0; j < 2; j++)
		{
			cout <<'\t'<<'\t'<<'\t';
			cout << q[i][j];
		}
		cout << endl;
	}
	cout << "Total" << '\t' << '\t' << '\t' << '\t' << total << endl << endl;
	double win = 0;
	for (int i = 0; i < 5; i++)
	{
		if (q[i][1] > win)
		{
			win = q[i][1];
		}
	}
	for (int i = 0; i < 5; i++)
	{
		if (q[i][1] == win)
		{
			cout << "The winner of the election is: " << p[i];
		}
	}
	cout << endl;
}

void input(string p[5], double *q[5], double total)
{
	cout << "enter the candidates names in order: ";
	for (int i = 0; i < 5; i++)
	{
		cin >> p[i];
	}
	for (int i = 0; i < 5; i++)
	{
		q[i] = new double[2];
	}
	cout << "Enter the number of votes each candidate recieved: ";
	for (int j = 0; j < 5; j++)
	{
		for (int k = 0; k < 1; k++)
		{
			cout << '\t';
			cin >> q[j][k];
		}
		cout << endl;
	}
	cout << fixed << showpoint << setprecision(2);
	for (int i = 0; i < 5; i++)
	{
		q[i][1] = (q[i][0] / total) * 100;
	}
}